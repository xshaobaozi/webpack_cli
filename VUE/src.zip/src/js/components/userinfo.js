const index = {
    "uinfo": {
        "new_user_mission": {
            "level_4": {
                "count": 0,
                "state": 0
            },
            "level_2": {
                "state": 0
            },
            "level_1": {
                "state": 0
            },
            "gift": {
                "state": 0,
                "gift_info": {
                    "gift_data": {
                        "2": 760,
                        "1001": 6
                    },
                    "gift_ts": 1513093445,
                    "uid": 190671247
                }
            },
            "level_3": {
                "count": 0,
                "state": 0
            }
        },
        "ccid": 251312693,
        "can_close": 1,
        "cquan": {
            "paid": 0,
            "free": 188,
            "ent_coin": 0
        },
        "can_recruit": false,
        "sign_type": -1,
        "wealth_level": {
            "nextlevelexp": 1000,
            "curlevelexp": 0,
            "uid": 190671247,
            "exp": 0,
            "level": 0
        },
        "anchor_level": {
            "uid": "190671247",
            "sublevel": 1,
            "mainlevel": 1,
            "exp": 0,
            "nextlevelexp": 2000,
            "curlevelexp": 0
        },
        "pop_window": 0,
        "urs": "gzpengyijun@corp.netease.com",
        "tips": "根据《网络安全法》规定，用户需绑定手机号才可继续使用服务（如无法绑定，请联系客服0571-26201152）",
        "purl": "http://cc.res.netease.com/webcc/portrait/nsep/headicon/builtin/30",
        "nickname": "路人1637",
        "uid": 190671247
    }
}

module.exports = index;