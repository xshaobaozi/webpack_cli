import hello from '@/js/components/pages/hello';
import two from '@/js/components/pages/two';

export default [
    {
      path: '/',
      name: 'Hello',
      component: hello
    },{
      path: '/a',
      name: 'Hello',
      component: two
    }
]